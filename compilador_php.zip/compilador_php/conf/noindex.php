<?php
#  Mostra os arquivos/diretorios do diretorio como um Index Of

$requisicao_server = $_SERVER["PHP_SELF"];

echo "<h1>Index of ".$_SERVER["SERVER_NAME"].$requisicao_server."</h1>";
echo "<a href='".dirname($requisicao_server)."'>< Diretório acima</a><br><br>";
foreach(glob($_SERVER['DOCUMENT_ROOT'].$requisicao_server.'/*',GLOB_NOSORT|GLOB_BRACE) as $f){
	$f=basename($f);
	echo "<a href='$requisicao_server/$f'>$f</a><br>";
}