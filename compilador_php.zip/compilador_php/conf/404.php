<h1>404 Página não encontrada</h1><br>
<a href='' onclick="window.history.go(-1); return false;"> < Voltar</a>
