<?php
#  Mostra os arquivos/diretorios do diretorio como um Index Of


header("Location: public/");