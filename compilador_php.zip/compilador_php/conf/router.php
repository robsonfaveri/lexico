<?php
#  Este arquivo controla o comportamento do servidor como o apache faria.  Toda requisição do navegador passa por ele
error_reporting(E_ALL & ~E_NOTICE);

#  Recebe a requisição da url
$requisicao_no_pc = $_SERVER['DOCUMENT_ROOT'].reset(@explode('?',$_SERVER['REQUEST_URI']));

#  se for um arquivo apenas abre
if(is_file($requisicao_no_pc)){		return false; 	 }

#  se n existe o caminho carrega 404
if(!is_dir($requisicao_no_pc)){ 	include('/404.php'); exit;     } 

#  Neste tentamos mover a execuçao para o local requerido
@chdir($requisicao_no_pc);

#  Verifica se no diretorio existe algum index
try{
	include($_SERVER['SCRIPT_FILENAME']);
}catch(Exception $e){
	print_r($e->getMessage());
 	include('/noindex.php'); 	
}